
%% Resultados en funci�n de gamma
% consideraremos que siempre tomamos muestras reordenadas
% tomando la funcion del PDF anterior, hacemos un ciclo sobre la gamma y
% obtenemos los siguientes resultados:
% podemos hacer busquedas en un intervalo de gamma, de valor de corte o
% bien del porcentaje de entrenamiento, podemos elegir si queremos que la
% muestra la tome aleatoriamente o solo los primeros valores.
%
% El programa toma por default para crear los archivos *.mod y *.nl la
% ruta donde se encuentran los programas, y necesita que la base de datos
% se encuentre en el mismo directorio con el formato presentado
% anteriormente

porc = zeros(51,1);
xx=linspace(0,5,51);
for i=0:50
[x1, porc(i+1)]=regL2 (((i+1)/100),.5,.1, 30,1,'/bin/AMPL/');
fprintf('evaluando iteracion %i de 50\n',i);
end
plot(xx,porc)
title('Predicci�n en funci�n de gamma');
%}


